# Copyright (C) 2013-2015 Red Hat, Inc.
#
# This work is licensed under the GNU GPLv2 or later.
# See the COPYING file in the top-level directory.

from .cliconfig import CLIConfig
